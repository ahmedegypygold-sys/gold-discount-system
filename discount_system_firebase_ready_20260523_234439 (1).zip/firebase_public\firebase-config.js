// Replace these values with your Firebase Web App config before deploying.
// Firebase Console -> Project settings -> Your apps -> Web app -> SDK setup and configuration.
window.FIREBASE_CONFIG = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_FIREBASE_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_FIREBASE_PROJECT_ID",
  storageBucket: "YOUR_FIREBASE_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_FIREBASE_SENDER_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};

// After publishing to Firebase, put your live site URL here.
// Example: window.PUBLIC_SITE_URL = "https://YOUR_FIREBASE_PROJECT_ID.web.app";
window.PUBLIC_SITE_URL = "";
